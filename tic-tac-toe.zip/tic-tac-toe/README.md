# Tic-tac-toe
Create a game with html, css and javascript.

You can play it here: https://codepen.io/trohalska/full/vYGGexg

![view game](https://i.postimg.cc/xCMgbgjm/tictactoe.png?raw=true "Title")
